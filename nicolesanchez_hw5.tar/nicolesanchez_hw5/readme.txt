Astronomy 598: Machine Learning (Winter 2017)
Student: Natalie Nicole Sanchez
Using Python 3.5.2
___________________________

Problem Set #5
___________________________

Part a:
nearest_neighbor(slength,swidth,plength,pwidth) 
function is found within trynn.py

Part b:
Run program trynn.py:
$ python trynn.py

To create nn.out 

Part c:
As seen in nn.out, each of the nearest neighbor values 
(for k=1) is the same as the real classification in iris.test.

Part d:
nearest_neighbor3(slength,swidth,plength,pwidth)
function is found within trynn3.py

Part e:
Run program trynn3.py:
$ python trynn3.py

To create nn3.out
